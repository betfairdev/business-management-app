// src/dtos/UpdateSubCategoryDto.ts
import { CreateSubCategoryDto } from './CreateSubCategoryDto';

export class UpdateSubCategoryDto extends CreateSubCategoryDto {}
