// src/dtos/UpdateBadgeDto.ts
import { CreateBadgeDto } from './CreateBadgeDto';

export class UpdateBadgeDto extends CreateBadgeDto {}
