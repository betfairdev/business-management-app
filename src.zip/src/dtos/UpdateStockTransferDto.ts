// src/dtos/UpdateStockTransferDto.ts
import { CreateStockTransferDto } from './CreateStockTransferDto';

export class UpdateStockTransferDto extends CreateStockTransferDto {}
