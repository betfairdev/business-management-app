// src/dtos/UpdateCategoryDto.ts
import { CreateCategoryDto } from './CreateCategoryDto';

export class UpdateCategoryDto extends CreateCategoryDto {}
