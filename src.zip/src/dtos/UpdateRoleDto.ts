// src/dtos/UpdateRoleDto.ts
import { CreateRoleDto } from './CreateRoleDto';

export class UpdateRoleDto extends CreateRoleDto {}
