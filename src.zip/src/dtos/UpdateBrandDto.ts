// src/dtos/UpdateBrandDto.ts
import { CreateBrandDto } from './CreateBrandDto';

export class UpdateBrandDto extends CreateBrandDto {}
