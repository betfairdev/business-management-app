// src/dtos/UpdateStoreDto.ts
import { CreateStoreDto } from './CreateStoreDto';

export class UpdateStoreDto extends CreateStoreDto {}