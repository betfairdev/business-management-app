// src/dtos/UpdateProductDto.ts
import { CreateProductDto } from './CreateProductDto';

export class UpdateProductDto extends CreateProductDto {}
