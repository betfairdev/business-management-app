<template>
  <footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
    <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <div class="flex items-center space-x-4">
          <p class="text-sm text-gray-500 dark:text-gray-400">
            © 2025 Business Manager. All rights reserved.
          </p>
        </div>
        
        <div class="flex items-center space-x-6 mt-4 md:mt-0">
          <span class="text-sm text-gray-500 dark:text-gray-400">
            Version 1.0.0
          </span>
          
          <div class="flex items-center space-x-2">
            <div class="h-2 w-2 bg-green-400 rounded-full"></div>
            <span class="text-sm text-gray-500 dark:text-gray-400">
              System Online
            </span>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>