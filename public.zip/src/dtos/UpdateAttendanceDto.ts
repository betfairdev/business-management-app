// src/dtos/UpdateAttendanceDto.ts
import { CreateAttendanceDto } from './CreateAttendanceDto';

export class UpdateAttendanceDto extends CreateAttendanceDto {}
