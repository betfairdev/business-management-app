import { CreateSaleReturnDto } from './CreateSaleReturnDto';

export class UpdateSaleReturnDto extends CreateSaleReturnDto {}