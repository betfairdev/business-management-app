// src/dtos/UpdatePurchaseReturnDto.ts
import { CreatePurchaseReturnDto } from './CreatePurchaseReturnDto';

export class UpdatePurchaseReturnDto extends CreatePurchaseReturnDto {}
