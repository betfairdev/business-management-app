// src/dtos/UpdateNoteDto.ts
import { CreateNoteDto } from './CreateNoteDto';

export class UpdateNoteDto extends CreateNoteDto {}
