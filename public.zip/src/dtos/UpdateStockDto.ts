// src/dtos/UpdateStockDto.ts
import { CreateStockDto } from './CreateStockDto';

export class UpdateStockDto extends CreateStockDto {}
