// src/dtos/UpdateIncomeDto.ts
import { CreateIncomeDto } from './CreateIncomeDto';

export class UpdateIncomeDto extends CreateIncomeDto {}