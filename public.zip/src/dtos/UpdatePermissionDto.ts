// src/dtos/UpdatePermissionDto.ts
import { CreatePermissionDto } from './CreatePermissionDto';

export class UpdatePermissionDto extends CreatePermissionDto {}
