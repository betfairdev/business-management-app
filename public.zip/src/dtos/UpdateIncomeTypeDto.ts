// src/dtos/UpdateIncomeTypeDto.ts
import { CreateIncomeTypeDto } from './CreateIncomeTypeDto';

export class UpdateIncomeTypeDto extends CreateIncomeTypeDto {}