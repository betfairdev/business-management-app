// src/dtos/UpdateSaleDto.ts
import { CreateSaleDto } from './CreateSaleDto';

export class UpdateSaleDto extends CreateSaleDto {}
