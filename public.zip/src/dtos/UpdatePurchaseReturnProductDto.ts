// src/dtos/UpdatePurchaseReturnProductDto.ts
import { CreatePurchaseReturnProductDto } from './CreatePurchaseReturnProductDto';

export class UpdatePurchaseReturnProductDto extends CreatePurchaseReturnProductDto {}
